int l_snmp_nsnwtput_enable (i_resource *self);
