void c_segfault_handler (int num);
void c_abort_handler (int num);
void c_sigchld_handler (int num);
void c_sighup_handler (int signo);
