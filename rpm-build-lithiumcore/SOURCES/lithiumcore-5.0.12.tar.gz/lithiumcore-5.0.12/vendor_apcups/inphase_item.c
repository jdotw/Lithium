#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>

#include "induction.h"
#include "induction/list.h"
#include "induction/timer.h"
#include "induction/form.h"
#include "induction/auth.h"
#include "induction/navtree.h"
#include "induction/navform.h"
#include "induction/hierarchy.h"
#include "induction/device.h"
#include "induction/path.h"
#include "device/snmp.h"

#include "inphase.h"

/* Item Struct Manipulation */

v_inphase_item* v_inphase_item_create ()
{
  v_inphase_item *item;

  item = (v_inphase_item *) malloc (sizeof(v_inphase_item));
  if (!item)
  { i_printf (1, "v_inphase_item_create failed to malloc v_inphase_item struct"); return NULL; }
  memset (item, 0, sizeof(v_inphase_item));

  return item;
}

void v_inphase_item_free (void *itemptr)
{
  v_inphase_item *item = itemptr;

  if (!item) return;

  free (item);
}
