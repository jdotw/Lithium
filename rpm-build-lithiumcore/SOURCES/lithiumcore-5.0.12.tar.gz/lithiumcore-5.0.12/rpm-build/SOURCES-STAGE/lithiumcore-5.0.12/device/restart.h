int l_restart_timercb (i_resource *self, struct i_timer_s *timer, void *passdata);
