int l_metform_generate (i_resource *self, i_entity *ent, i_form_reqdata *reqdata);
int l_metform_hist_generate (i_resource *self, i_entity *ent, i_form_reqdata *reqdata);
