#!/bin/sh

PKGCONFIG=pkg-config-0.25
LIBICONV=libiconv-1.13.1
LIBPNG=libpng-1.4.4
PIXMAN=pixman-0.19.6
FONTCONFIG=fontconfig-2.8.0
POPPLER=poppler-0.14.4
CAIRO=cairo-1.10.0
EXPAT=expat-2.0.1
GETTEXT=gettext-0.18.1.1
GLIB=glib-2.26.0
PANGO=pango-1.28.3
RRDTOOL=rrdtool-1.4.4

STAGE=$PWD/stage

PKG_CONFIG=$STAGE/bin/pkg-config
PKG_CONFIG_PATH=$STAGE/lib/pkgconfig  
PATH=$PATH:$STAGE/bin
CFLAGS="-I$STAGE/include"
LDFLAGS="-L$STAGE/lib" 

CONFIGURE_FLAGS="--prefix=$STAGE --enable-static PKG_CONFIG=$PKG_CONFIG PKG_CONFIG_PATH=$PKG_CONFIG_PATH PATH=$PATH CFLAGS=$CFLAGS LDFLAGS=$LDFLAGS"

#
# Staging
#

rm -rf $STAGE
mkdir -p $STAGE

# 
# Build 
#

# pkg-config
tar zxvf $PKGCONFIG.tar.gz
cd $PKGCONFIG
./configure $CONFIGURE_FLAGS && make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $PKGCONFIG

# libiconv
tar zxvf $LIBICONV.tar.gz
cd $LIBICONV
./configure $CONFIGURE_FLAGS && make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $LIBICONV

# libpng
tar zxvf $LIBPNG.tar.gz
cd $LIBPNG
./configure $CONFIGURE_FLAGS && make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $LIBPNG

# pixman
tar zxvf $PIXMAN.tar.gz
cd $PIXMAN
./configure $CONFIGURE_FLAGS && make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $PIXMAN

# fontconfig
tar zxvf $FONTCONFIG.tar.gz
cd $FONTCONFIG
./configure $CONFIGURE_FLAGS && make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $FONTCONFIG

# poppler
tar zxvf $POPPLER.tar.gz
cd $POPPLER
./configure $CONFIGURE_FLAGS --disable-poppler-qt --disable-poppler-qt4 --enable-xpdf-headers --enable-zlib --disable-gtk-test --without-x
if [ $? -ne 0 ]; then
  exit 1
fi
sed -i '' -e "s/DEFAULT_INCLUDES \=/DEFAULT_INCLUDES \= -I..\/..\/stage\/include/" cpp/Makefile
if [ $? -ne 0 ]; then
  exit 1
fi
make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $POPPLER

# cairo
tar zxvf $CAIRO.tar.gz
cd $CAIRO
./configure $CONFIGURE_FLAGS && make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $CAIRO

# expat
tar zxvf $EXPAT.tar.gz
cd $EXPAT
./configure $CONFIGURE_FLAGS && make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $EXPAT

# gettext
tar zxvf $GETTEXT.tar.gz
cd $GETTEXT
./configure $CONFIGURE_FLAGS && make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $GETTEXT

# glib
tar zxvf $GLIB.tar.gz
cd $GLIB
./configure $CONFIGURE_FLAGS && make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $GLIB

# pango
tar zxvf $PANGO.tar.gz
cd $PANGO
./configure $CONFIGURE_FLAGS && make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $PANGO

# rrdtool
tar zxvf $RRDTOOL.tar.gz
cd $RRDTOOL
./configure $CONFIGURE_FLAGS --disable-rrdcgi --enable-static-programs \
  --disable-libdbi --disable-perl --disable-ruby --disable-lua --disable-tcl\
  PKGCONFIG=$PKG_CONFIG && make && make install
if [ $? -ne 0 ]; then
  exit 1
fi
cd ..
rm -rf $RRDTOOL

#
# Get Result
#

rm -rf result
mkdir -p result
cp $STAGE/bin/rrd* result
rm -rf $STAGE

