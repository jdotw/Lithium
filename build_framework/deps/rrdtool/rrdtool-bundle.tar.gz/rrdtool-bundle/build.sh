#!/bin/bash

BASEDIR=$PWD

PREFIX=$BASEDIR/stage
RESULT=$BASEDIR/result

MAKEFLAGS=-j`sysctl -n hw.ncpu`

#
# Setup environment
# 

if [ $UID -ne 0 ]; then
  echo "ERROR: Build script must be run as root"
  exit 1
fi

rm -rf $PREFIX
mkdir $PREFIX

#
# Compile
# 

export PATH=$PREFIX/bin:$PATH

rm -rf pkg-config-0.23
tar zxvf pkg-config-0.23.tar.gz
cd pkg-config-0.23
./configure --prefix=$PREFIX --disable-shared --enable-static
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to configure pkg-config"
  exit 1
fi
make $MAKEFLAGS
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to compile pkg-config"
  exit 1
fi
make install
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to install pkg-config"
  exit 1
fi
cd ..

rm -rf pixman-0.11.10
tar jxvf pixman-0.11.10.tar.bz2
cd pixman-0.11.10
./configure --prefix=$PREFIX --disable-shared --enable-static PKG_CONFIG=$PREFIX/bin/pkg-config
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to configure pixman"
  exit 1
fi
make $MAKEFLAGS
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to compile pixman"
  exit 1
fi
make install
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to install pixman"
  exit 1
fi
cd ..

rm -rf libpng-1.2.31
tar jxvf libpng-1.2.31.tar.bz2
cd libpng-1.2.31
./configure --prefix=$PREFIX --disable-shared --enable-static PKG_CONFIG=$PREFIX/bin/pkg-config
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to configure libpng"
  exit 1
fi
make $MAKEFLAGS
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to compile libpng"
  exit 1
fi
make install
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to install libpng"
  exit 1
fi
cd ..

rm -rf cairo-1.4.14
tar zxvf cairo-1.4.14.tar.gz
cd cairo-1.4.14
./configure --prefix=$PREFIX --disable-shared --enable-static PKG_CONFIG=$PREFIX/bin/pkg-config --without-x --enable-atsui --enable-quartz
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to configure cairo"
  exit 1
fi
make $MAKEFLAGS
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to compile cairo"
  exit 1
fi
make install
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to install cairo"
  exit 1
fi
cd ..

rm -rf gettext-0.17
tar zxvf gettext-0.17.tar.gz
cd gettext-0.17
./configure --prefix=$PREFIX --disable-shared --enable-static PKG_CONFIG=$PREFIX/bin/pkg-config
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to configure gettext"
  exit 1
fi
make $MAKEFLAGS
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to compile cairo"
  exit 1
fi
make install
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to install cairo"
  exit 1
fi
cd ..

rm -rf glib-2.18.0
tar jxvf glib-2.18.0.tar.bz2
cd glib-2.18.0
./configure --prefix=$PREFIX --disable-shared --enable-static PKG_CONFIG=$PREFIX/bin/pkg-config LDFLAGS="-L$PREFIX/lib" CFLAGS="-I$PREFIX/include"
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to configure glib"
  exit 1
fi
make $MAKEFLAGS
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to compile glib"
  exit 1
fi
make install
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to install glib"
  exit 1
fi
cd ..

rm -rf pango-1.20.5
tar jxvf pango-1.20.5.tar.bz2
cd pango-1.20.5
./configure --prefix=$PREFIX --sysconfdir=/Library/Lithium/LithiumCore.app/Contents/Resources/pango --enable-cairo --disable-shared --enable-static --with-included-modules=yes --with-dynamic-modules=no PKG_CONFIG=$PREFIX/bin/pkg-config LDFLAGS="-L$PREFIX/lib" LIBS="-lpixman-1 -lz -lpng -framework Carbon -framework CoreFoundation -framework ApplicationServices -framework AppKit"
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to configure pango"
  exit 1
fi
make $MAKEFLAGS
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to compile pango"
  exit 1
fi
make install
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to install pango"
  exit 1
fi
cd ..

rm -rf rrdtool-1.3.4
tar zxvf rrdtool-1.3.4.tar.gz
cd rrdtool-1.3.4
./configure --prefix=$PREFIX --disable-shared --enable-static PKG_CONFIG=$PREFIX/bin/pkg-config CFLAGS="-I$PREFIX/include" LDFLAGS="-L$PREFIX/lib  -lpixman-1 -lz -lpng -framework Carbon -framework CoreFoundation -framework ApplicationServices -framework AppKit" --disable-perl --disable-python --disable-rrdcgi --enable-static-programs --disable-tcl --disable-ruby
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to configure rrdtool"
  exit 1
fi
make $MAKEFLAGS
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to compile rrdtool"
  exit 1
fi
make install
if [ $? -ne 0 ]; then
  echo "ERROR: Failed to install rrdtool"
  exit 1
fi
cd ..

rm -rf cairo-1.4.14
rm -rf gettext-0.17
rm -rf glib-2.18.0
rm -rf libpng-1.2.31
rm -rf pango-1.20.5
rm -rf pixman-0.11.10
rm -rf pkg-config-0.23
rm -rf rrdtool-1.3.4

mkdir $RESULT
cp $PREFIX/bin/rrdtool $RESULT
cp $PREFIX/bin/rrdupdate $RESULT
rm -rf $PREFIX

