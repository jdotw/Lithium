int i_opstate_change (i_resource *self, i_entity *ent, short state);
short i_opstate_eval (i_resource *self, i_entity *ent);
