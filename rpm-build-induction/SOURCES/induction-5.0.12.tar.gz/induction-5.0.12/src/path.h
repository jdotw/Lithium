char* i_path_extract_filename (char *path);
char* i_path_glue (char *path, char *file);
char* i_path_socket (char *ident, char *name);
int i_path_mkdir (char *path, mode_t mode);
char* i_path_escape_spaces (char *path);
