long i_sms_send (i_resource *self, struct i_user_s *user, struct i_notification_s *note);
