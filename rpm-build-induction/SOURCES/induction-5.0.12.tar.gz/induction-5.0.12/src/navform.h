/* navform.c */
int form_navigation_menu (i_resource *self, struct i_form_reqdata_s *reqdata);
int i_navform_render_navtree (i_resource *self, struct i_form_s *form, struct i_navtree_node_s *node, unsigned short level);
