/* svcregistry.c */
long i_svcregistry_register (i_resource *self, struct i_object_s *ip);
long i_svcregistry_deregister (i_resource *self, i_resource_address *custaddr, i_resource_address *devaddr, struct i_object_s *ip);

