int i_devnormal_report (i_resource *self);
