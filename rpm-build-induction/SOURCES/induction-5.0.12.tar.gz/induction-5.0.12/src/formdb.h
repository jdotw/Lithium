i_form* i_formdb_get (i_resource *self, char *form_name);
int i_formdb_put (i_resource *self, char *form_name, i_form *form);
int i_formdb_del (i_resource *self, char *form_name);
