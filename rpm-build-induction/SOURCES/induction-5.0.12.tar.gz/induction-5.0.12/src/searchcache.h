int i_searchcache_insert (i_resource *self, i_entity *entity);
int i_searchcache_delete (i_resource *self, i_entity *entity);
