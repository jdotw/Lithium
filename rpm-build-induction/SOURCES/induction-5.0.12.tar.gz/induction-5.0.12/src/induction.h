/* Common includes */
#include <uuid/uuid.h>
#ifdef INDUCTION
#include "resource.h"
#include "printf.h"
#else
#include <induction/printf.h>
#include <induction/resource.h>
#endif

