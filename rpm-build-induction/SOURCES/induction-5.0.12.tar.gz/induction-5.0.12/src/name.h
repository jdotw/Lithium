/* name.c */

int i_name_parse (char *name_str);
