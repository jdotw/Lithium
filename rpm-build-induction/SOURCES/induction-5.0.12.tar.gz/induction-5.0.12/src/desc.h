/* desc.c */

int i_desc_parse (char *desc_str);
