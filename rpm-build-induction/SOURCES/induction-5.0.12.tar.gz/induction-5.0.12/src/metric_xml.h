void i_metric_xml (struct i_entity_s *ent, xmlNodePtr ent_node, unsigned short flags);
void i_metric_xml_summary (struct i_entity_s *ent, xmlNodePtr ent_node, unsigned short flags);
xmlNodePtr i_metric_value_xml (struct i_metric_s *met, struct i_metric_value_s *val);
xmlNodePtr i_metric_enumstr_xml (struct i_metric_enumstr_s *enumstr);
