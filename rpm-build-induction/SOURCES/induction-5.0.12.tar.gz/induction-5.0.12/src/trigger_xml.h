void i_trigger_xml (i_entity *ent, xmlNodePtr ent_node, unsigned short flags);
