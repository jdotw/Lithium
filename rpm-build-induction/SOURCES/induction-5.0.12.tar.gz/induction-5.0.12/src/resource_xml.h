xmlNodePtr i_resource_address_xml (struct i_resource_address_s *resaddr);
