xmlNodePtr i_incident_xml (struct i_incident_s *inc);
