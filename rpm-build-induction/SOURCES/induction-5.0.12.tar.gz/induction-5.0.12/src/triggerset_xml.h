/* triggerset_apprule_xml.c */
xmlNodePtr i_triggerset_apprule_xml (i_triggerset_apprule *rule);

/* i_triggerset_valrule_xml.c */
xmlNodePtr i_triggerset_valrule_xml (i_triggerset_valrule *rule);
  

