int i_adminstate_change (i_resource *self, i_entity *ent, unsigned short state);
