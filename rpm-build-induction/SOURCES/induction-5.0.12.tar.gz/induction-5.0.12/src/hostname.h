void i_hostname_set (char *hostname, int len);
