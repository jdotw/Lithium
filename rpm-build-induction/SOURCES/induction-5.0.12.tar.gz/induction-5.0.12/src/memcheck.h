float i_memcheck_rss ();
float i_memcheck_vss ();

int i_memcheck_perflog_timer (i_resource *self, struct i_timer_s *timer, void *passdata);

