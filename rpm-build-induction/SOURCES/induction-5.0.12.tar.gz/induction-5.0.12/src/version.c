#include <stdio.h>
#include <stdlib.h>

#include "induction.h"
#include "version.h"

char* i_version ()
{ return INDUCTION_VERSION; }

