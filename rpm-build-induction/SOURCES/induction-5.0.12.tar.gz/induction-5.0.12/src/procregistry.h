/* procregistry.c */
long i_procregistry_register (i_resource *self, struct i_object_s *process);
long i_procregistry_deregister (i_resource *self, i_resource_address *custaddr, i_resource_address *devaddr, struct i_object_s *process);

