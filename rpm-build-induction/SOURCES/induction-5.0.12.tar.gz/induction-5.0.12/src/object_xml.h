void i_object_xml (i_entity *ent, xmlNodePtr ent_node, unsigned short flags);
