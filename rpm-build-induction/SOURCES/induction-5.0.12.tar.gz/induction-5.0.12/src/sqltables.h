/*
 * SQL Table names 
 */

#define SQLTABLE_CUSTOMERS "customers"
#define SQLTABLE_SITES "sites"
#define SQLTABLE_DEVICES "devices"

#define SQLTABLE_ENTREF_CONFIG "entity_refresh_config"
