void ascii_dump (char *data, int datasize);
