int i_init (i_resource *self);
