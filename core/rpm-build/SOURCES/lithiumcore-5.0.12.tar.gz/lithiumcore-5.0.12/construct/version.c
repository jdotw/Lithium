#include <stdio.h>
#include <stdlib.h>

#include <induction.h>
#include <induction/version.h>

void c_version ()
{
  printf ("%s\n", i_version());
}
