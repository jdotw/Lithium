int v_index_refcb (i_resource *self, i_metric *index, void *passdata);
