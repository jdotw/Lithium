/* pdfgraph_xml_render.c */
int xml_pdfgraph_render (i_resource *self, i_xml_request *xmlreq);
