#include <stdlib.h>

#include <induction.h>

#include "feature.h"

int l_feature_enable (i_resource *self, l_feature *feat)
{

}

int l_feature_disable (i_resource *self, l_feature *feat)
{

}
