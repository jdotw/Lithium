int l_osx_present();
void l_osx_set_present(int value);
int l_osx_version();
void l_osx_set_version(int value);
