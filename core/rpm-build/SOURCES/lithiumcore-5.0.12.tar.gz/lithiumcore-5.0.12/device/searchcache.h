int l_searchcache_init (i_resource *self);
