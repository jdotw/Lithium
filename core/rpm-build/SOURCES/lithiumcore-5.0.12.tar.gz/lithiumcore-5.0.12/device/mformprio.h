/*
 * Priorities for mainform sections
 */

#define MFORMPRIO_STATUS 0
#define MFORMPRIO_AVAIL 50
#define MFORMPRIO_IFACE 100
#define MFORMPRIO_RESPTIME 1000

