/* pdfgraph_xml_render.c */
int xml_xmlgraph_render (i_resource *self, i_xml_request *xmlreq);
int l_xmlgraph_xml_render_graphcb (i_resource *self, struct i_rrdtool_cmd_s *cmd, int result, void *passdata);
