int l_trgform_generate (i_resource *self, i_entity *ent, i_form_reqdata *reqdata);
int l_trgform_hist_generate (i_resource *self, i_entity *ent, i_form_reqdata *reqdata);
