cat $1 | sed s/i_avail/l_avail/g > temp; mv temp $1;

