int module_shutdown (i_resource *self);
