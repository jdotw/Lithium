int l_cntform_generic (i_resource *self, i_entity *ent, i_form_reqdata *reqdata);
