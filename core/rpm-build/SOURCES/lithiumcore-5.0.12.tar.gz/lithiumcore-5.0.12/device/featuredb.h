int l_featuredb_put (i_resource *self, l_feature *feat);
int l_featuredb_del (i_resource *self, char *id_str);
