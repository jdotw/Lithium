int xml_rrdxport (i_resource *self, struct i_xml_request_s *xmlreq);
int l_rrdxport_xportcb (i_resource *self, struct i_rrdtool_cmd_s *cmd, int result, void *passdata);
