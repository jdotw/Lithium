cat $1 | sed s/i_snmp/l_snmp/g > temp; mv temp $1;

