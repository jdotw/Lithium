int l_navtree_func (i_resource *self, struct i_entity_s *ent, struct i_navtree_node_s *root);
