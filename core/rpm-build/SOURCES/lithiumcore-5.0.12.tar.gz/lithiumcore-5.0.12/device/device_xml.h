int l_device_xml (i_entity *ent, xmlNodePtr ent_node);
